#Alexis Raulais Amaury Herbaut de Saint Just 

library(FactoMineR)

data(JO)
JO
#Ligne -> Athlé
# Colonne -> Pays

#Oui nous avons un avons un tableau de contingence entre les données d'athlétisme et de pays.
#Les individus sont les disciplines sportives tandis que les varibales associées à chaque individu sont les pays avec leur nombre de médaille remporté.

table(JO)
barplot(table(JO))

#Le nombre de cellule contenant 0 est 1211.
#C'est le Kenya pour le 3000mSteeple
rev(sort(apply(JO,2,sum)))

CA(JO)
resca=CA(JO)
resca

#La valeur du Chi2 est 2122.231. Le p-value est très faible, en dessous de 5% donc on rejette H0 ce qui signifie que c'est dépendant.
round(resca$eig,2)
barplot(resca$eig[,1], names.arg = c(1:23)
#Il faut utiliser les 23 axes pour n'avoir aucune perte d'inertie. Chaque axe apport 4,35% ( 100/23 ) d'information avanc AFC.
#Il faut 9 axes nécessaires pour représenter tous les profils lignes-colonnes.  Car on prend toutes les valeurs au dessus de 4,35.
#Cest 24.38. Ce qui est plutôt faible, donc on aura besoin de plusieurs plan pour montrer toutes les informations.

plot(resca,axes=1:2)
resca$row
resca$col
round(resca$row$contrib,2)
round(resca$col$contrib,2)

#10000m, 5000m et 3000mSteeple contribue le plus à l'axe 1. Les courses d'endurance contribue à l'axe 1.
#Disque et Marteau contribue le plus à l'axe 2.

#Kenya, Ethiopie
#Lituanie, USA, Blr

#Que le Kenya gagne plus souvent les épreuves de 10 000m et la Lituanie les épreuves de Disque.

#L'épreuve du 110mH,  Decathlon, Hauteur, Javelot, Longueur et poids.
#Bar, Bra, Brn, Chn, Den, Dom, Fra, Kaz, 

plot(resca,axes=3:4)
resca$row
resca$col
round(resca$row$contrib,2)
round(resca$col$contrib,2)

#Disque, Javelot et 20km.
#20km, Javelot.

#Blr, Fin, Hun, USA,
#Aus, Cze, Ecu, FIn, Ltu, Nor

#Les pays avec les valeurs les plus faibles sur l'axe 3 et 4.

library(cluster)
resclassif<-agnes(resca$col$coord[,1:4], method="ward")
plot(resclassif)

#Nous allons choisir 5 groupes.
numclassward=cutree(resclassif, k=5) 
numclassward
plot(resca$col$coord[,1:2],col=numclassward)

paysward=cbind.data.frame(t(JO)[,1:24],as.factor(numclassward))
colnames(paysward)[25]="Classward"
		
		
		


