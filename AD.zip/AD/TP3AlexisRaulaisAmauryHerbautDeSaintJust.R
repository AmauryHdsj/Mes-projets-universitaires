library(cluster) 
library(FactoMineR) 
tel= read.table("tel1984.txt", row.names = 1, header = T, dec = ",") 
tel

resclus=kmeans(tel[,1:7],4, algorithm = "Lloyd") 
resclus

#Groupe choisi : Ils ont une inertie intra-total la plus faible
#1 : Ajaccio
#2 : Lille, Marseille, Montpellier, Paris
#3 : Besancon, Chalons, Clermont, Dijon, Lyon, Nancy, Nantes, Orleans, Strasbourg
#4 : Amiens, Bordeaux, Caen, Limoges, Poitiers, Rennes, Rouen, Toulouse

#les num ́eros des groupes auxquels ap- partiennent chaque individu 
resclus$cluster 
#les barycentres de chaque groupe
resclus$centers 
#l’inertie intra-classe de chaque groupe
resclus$withinss 
#l’inertie intra-totale
 resclus$tot.withinss 
 #le nombre d’individus dans chaque groupe
 resclus$size 
 
 #En faisant plusieurs essais on trouve 797.8887 qui est l'inertie intra-total la plus faible.

plot(tel$igqs,tel$ezaa,col=resclus$cluster)
tel = cbind(tel, as.factor(resclus$cluster))
colnames(tel)[9] = "Classe km" 

catdes(tel[,c(1:7,9)], num.var=8)

#C'est normal que Ajaccio sois tout seul car il est différent des autres et le plus éloigné.
#Amaury à dis que Ajaccio était la plus corroborée.

#Dans le premier groupe nous avons que Ajaccio. La varibales la plus fortes est 'tsi' car supérieur à 1,96. Tandis que les plus faibles sont vr2, igqs, ezaa, izaa, tcr et tcom qui sont inférieur à -1,96.
#Dans le 2nd groupe nous avons simplement tcr qui est inférieur à -1,96.
#Dans le groupe 3 on à tcr, ezaa, igqs, vr2 et izaa les plus fortes et tsi la plus faible.
#Dans le dernier groupe, on a tsi qui est légerement supérieur à 1,96.

resclusnorm=kmeans(scale(tel[,1:7]),4, algorithm = "Lloyd")
resclusnorm

#les num ́eros des groupes auxquels ap- partiennent chaque individu 
resclusnorm$cluster 
#les barycentres de chaque groupe
resclusnorm$centers 
#l’inertie intra-classe de chaque groupe
resclusnorm$withinss 
#l’inertie intra-totale
 resclusnorm$tot.withinss 
 #le nombre d’individus dans chaque groupe
 resclusnorm$size 

#En faisant plusieurs essais on trouve 27.7704 qui est l'inertie intra-total la plus faible.
#Groupe choisi : 
#1 : Bordeaux, Caen, Limoges, Marseille, Montpellier, Poitier, Rouen, Toulouse
#2 : Ajaccio
#3 : Besancon, Chalons, Clermont, Dijon, Nancy, Strasbourg
#4 : Amiens, Lille, Lyon, Nantes, Orelans, Rennes, Paris

#On remarque que les groupes sont différents par rapport au premier.

plot(tel$igqs,tel$ezaa,col= resclusnorm$cluster)

tel = cbind(tel, as.factor(resclusnorm$cluster))
colnames(tel)[9] = "Classe kmnorm" 
catdes(tel[,c(1:7,10)], num.var = 8) 
#1er groupe -> tsi qui est la plus forte. Les plus faibles sont vr2, igqs, ezaa, izaa, tcr, tcom.
#2 -> tcr est la plus faible. Nous avons que ajaccio dans ce groupe.
#3 -> Les plus fortes sont tcr, ezaa, igqs, vr2, izaa. Et la plus faible tsi.
#4 -> La plus forte est tsi.
#On remarque que nous obtenons des groupes qui correspondent mieux à l'ACP. Ce qui est plus pertinent pour évaluer les valeurs.

rescah = agnes(scale(tel[,1:7]), method = "ward")
plot(rescah, xlab = "regions")

rescahmin = agnes(scale(tel[,1:7]), method = "single")
plot(rescahmin , xlab = "regions")
#On remarque que ajaccio n'ai pas présent avec les autres. 
rescahmax = agnes(scale(tel[,1:7]), method = "complete")
plot(rescahmax , xlab = "regions")
#On remarque que dans tous les cas Ajaccio n'appartient pas à un groupe.
numclassward=cutree(rescah, k=4) 
numclassward
numclassmax=cutree(rescahmax, k=4)
numclassmax
table(numclassward, numclassmax)
#On constate qu'ils se ressemblent fortement.
tel = cbind(tel, as.factor(numclassward))
colnames(tel)[11] = "ClassesCAHW"
rescah2=as.hclust(rescah)
rescah2
barplot(rev(rescah2$height), names.arg = c(1:21))  
catdes(tel[, c(1:7, 11)], num.var = 8)
#On remarque que c'est le groupe 3 qui est à le meilleur réseaux. Donc les villes du groupes "Besancon, Chalons, Clermont, Dijon, Nancy, Strasbourg".
#On obtient les mêmes valeurs avec le k-means


		
		  

 











 
		
		

