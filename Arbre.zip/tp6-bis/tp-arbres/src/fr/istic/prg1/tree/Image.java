package fr.istic.prg1.tree;

import java.util.Scanner;

import fr.istic.prg1.tree_util.AbstractImage;
import fr.istic.prg1.tree_util.Iterator;
import fr.istic.prg1.tree_util.Node;
import fr.istic.prg1.tree_util.NodeType;

/**
 * @author Mickaël Foursov <foursov@univ-rennes1.fr>
 * @version 5.0
 * @since 2023-09-23
 * 
 *        Classe décrivant les images en noir et blanc de 256 sur 256 pixels
 *        sous forme d'arbres binaires.
 * 
 */

public class Image extends AbstractImage {
	private static final Scanner standardInput = new Scanner(System.in);

	public Image() {
		super();
	}

	public static void closeAll() {
		standardInput.close();
	}

	/**
	 * this devient identique à image2.
	 *
	 * @param image2 image à copier
	 *
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void affect(AbstractImage image2) {
		if (this != image2) {
			Iterator<Node> it1 = this.iterator();
			Iterator<Node> it2 = image2.iterator();
			it1.clear();
			affectAux(it1, it2);
		}
	}

	private void affectAux(Iterator<Node> it1, Iterator<Node> it2) {
		if (!it2.isEmpty()) {
			it1.addValue(it2.getValue());

			it2.goLeft();
			it1.goLeft();
			affectAux(it1, it2);
			it2.goUp();
			it1.goUp();

			it2.goRight();
			it1.goRight();
			affectAux(it1, it2);
			it2.goUp();
			it1.goUp();
		}
	}

	/**
	 * this devient rotation de image2 à 180 degrés.
	 *
	 * @param image2 image pour rotation
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void rotate180(AbstractImage image2) {
		if (!image2.isEmpty()) {
			Iterator<Node> it1 = this.iterator();
			Iterator<Node> it2 = image2.iterator();
			it1.clear();
			rotate180Aux(it1, it2);
		}
	}

	private void rotate180Aux(Iterator<Node> it1, Iterator<Node> it2) {
		if (!it2.isEmpty()) {
			it1.addValue(it2.getValue());

			it1.goLeft();
			it2.goRight();
			rotate180Aux(it1, it2);
			it1.goUp();
			it2.goUp();

			it1.goRight();
			it2.goLeft();
			rotate180Aux(it1, it2);
			it1.goUp();
			it2.goUp();
		}
	}

	/**
	 * this devient inverse vidéo de this, pixel par pixel.
	 *
	 * @pre !image.isEmpty()
	 */
	@Override
	public void videoInverse() {
		if (!this.isEmpty()) {
			Iterator<Node> it = this.iterator();
			videoInverseAux(it);
		}
	}
	private void videoInverseAux(Iterator<Node> it) {
		if (!it.isEmpty()) {
			if (it.getValue().state == 1) {
				it.setValue(Node.valueOf(0));
			} else if (it.getValue().state == 0) {
				it.setValue(Node.valueOf(1));
			} else {
				it.goLeft();
				videoInverseAux(it);
				it.goUp();
				it.goRight();
				videoInverseAux(it);
				it.goUp();
			}
		}
	}
	/**
	 * this devient image miroir verticale de image2.
	 *
	 * @param image2 image à agrandir
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void mirrorV(AbstractImage image2) {
		if(!image2.isEmpty()){
			Iterator<Node>it1=this.iterator();
			Iterator<Node>it2=image2.iterator();
			mirrorVaux(it1,it2,true);
		}
	}
	private void mirrorVaux(Iterator<Node> it1, Iterator<Node> it2, boolean impair) {
		if (!it2.isEmpty()) {
			it1.addValue(it2.getValue());
			if (impair) {

				it1.goLeft();
				it2.goRight();
				mirrorVaux(it1, it2, !impair);
				it1.goUp();
				it2.goUp();

				it1.goRight();
				it2.goLeft();
				mirrorVaux(it1, it2, !impair);
				it1.goUp();
				it2.goUp();
			} else {

				it1.goLeft();
				it2.goLeft();
				mirrorVaux(it1, it2, !impair);
				it1.goUp();
				it2.goUp();

				it1.goRight();
				it2.goRight();
				mirrorVaux(it1, it2, !impair);
				it1.goUp();
				it2.goUp();
			}
		}
	}

	/**
	 * this devient image miroir horizontale de image2.
	 *
	 * @param image2 image à agrandir
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void mirrorH(AbstractImage image2) {
		if(!image2.isEmpty()){
			Iterator<Node>it1=this.iterator();
			Iterator<Node>it2=image2.iterator();
			it1.clear();
			mirrorHaux(it1,it2,true);
		}
	}
	private void mirrorHaux(Iterator<Node>it1,Iterator<Node>it2,boolean impair){
		if (!it2.isEmpty()) {
			it1.addValue(it2.getValue());  // Ajouter la valeur de it2 à it1
			if (impair) {
				it1.goLeft();
				it2.goLeft();
				mirrorVaux(it1, it2, impair);  // Récursivement miroir pour le sous-arbre gauche
				it1.goUp();
				it2.goUp();

				it1.goRight();
				it2.goRight();
				mirrorVaux(it1, it2, impair);  // Récursivement miroir pour le sous-arbre droit
				it1.goUp();
				it2.goUp();


			} else {
				it1.goLeft();
				it2.goRight();
				mirrorVaux(it1, it2, impair);  // Récursivement miroir pour le sous-arbre gauche
				it1.goUp();
				it2.goUp();

				it1.goRight();
				it2.goLeft();
				mirrorVaux(it1, it2, impair);  // Récursivement miroir pour le sous-arbre droit
				it1.goUp();
				it2.goUp();


			}
		}

	}
	/**
	 * this devient quart supérieur gauche de image2.
	 *
	 * @param image2 image à agrandir
	 *
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void zoomIn(AbstractImage image2) {
		if(!image2.isEmpty()){
			Iterator<Node>it1=this.iterator();
			Iterator<Node>it2= image2.iterator();
			it1.clear();
			it2.goLeft();

			if(it2.getValue().state!=2){
				it1.addValue(it2.getValue());
			}else{
				it2.goLeft();
				zoomInaux(it1,it2);
			}

		}

	}
	private void zoomInaux(Iterator<Node>it1,Iterator<Node>it2){

		if(!it2.isEmpty()){

				it1.addValue(it2.getValue());
				it1.goLeft();
				it2.goLeft();
				zoomInaux(it1,it2);
				it1.goUp();
				it2.goUp();
				it1.goRight();
				it2.goRight();
				zoomInaux(it1,it2);
				it1.goUp();
				it2.goUp();
			}


	}

	/**
	 * Le quart supérieur gauche de this devient image2, le reste de this devient
	 * éteint.
	 *
	 * @param image2 image à réduire
	 * @pre !image2.isEmpty()
	 */
	@Override
	public void zoomOut(AbstractImage image2) {
		if(!image2.isEmpty()){
			Iterator<Node>it1=this.iterator();
			Iterator<Node>it2= image2.iterator();
			it1.clear();
			zoomOutAux(it1,it2);

		}
	}
	private void zoomOutAux(Iterator<Node> it1, Iterator<Node> it2) {
		if (!it2.isEmpty()) {
			if (it2.getValue().state == 1) {
				it1.addValue(Node.valueOf(0));
			} else {
				it1.addValue(it2.getValue());

				it1.goLeft();
				it2.goLeft();
				zoomOutAux(it1, it2);
				it1.goUp();
				it2.goUp();

				it1.goRight();
				it2.goRight();
				zoomOutAux(it1, it2);
				it1.goUp();
				it2.goUp();
			}
		}
	}


	/**
	 * this devient l'intersection de image1 et image2 au sens des pixels allumés.
	 * 
	 * @pre !image1.isEmpty() && !image2.isEmpty()
	 * 
	 * @param image1 premiere image
	 * @param image2 seconde image
	 */
	@Override
	public void intersection(AbstractImage image1, AbstractImage image2) {
		Iterator<Node>it1= this.iterator();
		Iterator<Node>it2=image1.iterator();
		Iterator<Node>it3= image2.iterator();
		it1.clear();
		if(!image2.isEmpty() && !image1.isEmpty()){
			if(image1==image2){
				affect(image1);
			}else{
				intersectionAux(it1,it2,it3);
			}
		}
	}
	public void intersectionAux(Iterator<Node> it, Iterator<Node> it1, Iterator<Node> it2) {
		if (!it1.isEmpty() || !it2.isEmpty()) {
			it.clear();
			if (it1.getValue().state == 1 && it2.getValue().state == 1) {
				it.addValue(it1.getValue());
			} else if (it1.getValue().state == 0 || it2.getValue().state == 0) {
				Node n = Node.valueOf(0);
				it.addValue(n);
			} else if (it1.getValue().state == 2 && it2.getValue().state == 1) {
				affectAux(it, it1);
			} else if (it1.getValue().state == 1 && it2.getValue().state == 2) {
				affectAux(it, it2);
			} else {
				it.addValue(it1.getValue());
				it.goRight();
				it1.goRight();
				it2.goRight();
				intersectionAux(it, it1, it2);
				Node fDroit = it.getValue();
				it.goUp();
				it1.goUp();
				it2.goUp();
				it.goLeft();
				it1.goLeft();
				it2.goLeft();
				intersectionAux(it, it1, it2);
				Node fGauche = it.getValue();
				it.goUp();
				it1.goUp();
				it2.goUp();

				if ((fDroit.state == 0 && fGauche.state == 0) || (fDroit.state == 1 && fGauche.state == 1)) {
					it.goLeft();
					it.remove();
					it.goUp();
					it.goRight();
					it.remove();
					it.goUp();
					it.setValue(fDroit);
				}
			}
		}
	}



	/**
	 * this devient l'union de image1 et image2 au sens des pixels allumés.
	 * 
	 * @pre !image1.isEmpty() && !image2.isEmpty()
	 * 
	 * @param image1 premiere image
	 * @param image2 seconde image
	 */
	@Override
	public void union(AbstractImage image1, AbstractImage image2) {
		Iterator<Node>it1= this.iterator();
		Iterator<Node>it2=image1.iterator();
		Iterator<Node>it3= image2.iterator();
		it1.clear();
		unionAux(it1,it2,it3);
	}
	private void unionAux(Iterator<Node> it1, Iterator<Node> it2, Iterator<Node> it3) {
		int state2 = it2.getValue().state;
		int state3 = it3.getValue().state;

		if (state2 == 1 || state3 == 1) {
			it1.addValue(Node.valueOf(1));
		} else if (state2 == 0 && state3 == 0) {
			it1.addValue(Node.valueOf(0));
		} else if (state2 == 0) {
			affectAux(it1, it3);
		} else if (state3 == 0) {
			affectAux(it1, it2);
		} else {
			it1.addValue(Node.valueOf(2));
			Node childleft = Node.valueOf(2);
			Node childright = Node.valueOf(2);

			it1.goLeft();
			it2.goLeft();
			it3.goLeft();
			unionAux(it1, it2, it3);
			childleft = it1.getValue();
			it1.goUp();
			it2.goUp();
			it3.goUp();

			it1.goRight();
			it2.goRight();
			it3.goRight();
			unionAux(it1, it2, it3);
			childright = it1.getValue();
			it1.goUp();
			it2.goUp();
			it3.goUp();

			if (childleft.equals(Node.valueOf(1)) && childright.equals(Node.valueOf(1))) {
				it1.clear();
				it1.addValue(childleft);
			}
		}
	}


	/**
	 * Attention : cette fonction ne doit pas utiliser la commande isPixelOn
	 * 
	 * @return true si tous les points de la forme (x, x) (avec 0 <= x <= 255)
	 *         sont allumés dans this, false sinon
	 */
	@Override
	public boolean testDiagonal() {
		Iterator<Node> it = this.iterator();
		if (!this.isEmpty()) {

			if(it.getValue().state==1){
				return true;
			}
			else if(it.getValue().state==0){
				return false;
			}


		}
		return testDiagonalAux(it);
	}



		private boolean testDiagonalAux(Iterator<Node> iter) {
		boolean gDiag = false;
		boolean dDiag = false;
		if(iter.getValue().state == 2) {


				iter.goLeft();
				if(iter.getValue().state == 2) {
					iter.goLeft();
					gDiag = testDiagonalAux(iter);
					iter.goUp();
				}
				else gDiag = (iter.getValue().state == 1);

			    iter.goUp();
				iter.goRight();
				if(gDiag && iter.getValue().state == 2) {
					iter.goRight();
					dDiag = testDiagonalAux(iter);
					iter.goUp();
				}
				else dDiag = (iter.getValue().state == 1);
				iter.goUp();
				return gDiag && dDiag;
			}
			else return iter.getValue().state== 1;
		}




	/**
	 * @param x abscisse du point
	 * @param y ordonnée du point
	 * @pre !this.isEmpty()
	 * @return true, si le point (x, y) est allumé dans this, false sinon
	 */
	@Override
	public boolean isPixelOn(int x, int y) {
			Iterator<Node>it=this.iterator();
			int xDeb=0, xFin=255, yDeb=0, yFin=255, milieux=0;

			boolean decoupH=true;

			while(it.getValue().state==2){
				//partie horizontale


				if(decoupH) {
					milieux = (yDeb + yFin) / 2;
					if (y <= milieux) {
						it.goLeft();
						yFin = milieux;
					} else {
						it.goRight();
						yDeb = milieux;
					}
					decoupH = false;
				}
				//partie verticale
				else {
					milieux=(xDeb+xFin)/2;
					if(x<=milieux){
						it.goLeft();
						xFin=milieux;
					}else{
						it.goRight();
						xDeb=milieux;
					}
					decoupH=true;
				}
			}


			return it.getValue().state==1;
		}

	/**
	 * @param x1 abscisse du premier point
	 * @param y1 ordonnée du premier point
	 * @param x2 abscisse du deuxième point
	 * @param y2 ordonnée du deuxième point
	 * @pre !this.isEmpty()
	 * @return true si les deux points (x1, y1) et (x2, y2) sont représentés par la
	 *         même feuille de this, false sinon
	 */
	@Override
	public boolean sameLeaf(int x1, int y1, int x2, int y2) {
		int XMAX = 256;
		int debutX = 0;
		int YMAX = 256;
		int debutY = 0;

		Iterator<Node> it1 = this.iterator();
		Iterator<Node> it2 = this.iterator();
		while (it1.getValue().state == 2) {
			int milieuX = (XMAX + debutX) / 2;
			int milieuY = (YMAX + debutY) / 2;

			if ((XMAX - debutX) == (YMAX - debutY)) {
				if (y1 < milieuY && y2 < milieuY) {
					it1.goLeft();
					it2.goLeft();
					YMAX = milieuY;
				} else if (y1 >= milieuY && y2 >= milieuY) {
					it1.goRight();
					it2.goRight();
					debutY = milieuY;
				} else {
					return false;
				}
			} else {
				if (x1 < milieuX && x2 < milieuX) {
					it1.goLeft();
					it2.goLeft();
					XMAX = milieuX;
				} else if (x1 >= milieuX && x2 >= milieuX) {
					it1.goRight();
					it2.goRight();
					debutX = milieuX;
				} else {
					return false;
				}
			}
		}

		return true;
	}


	/**
	 * @param image2 autre image
	 * @pre !this.isEmpty() && !image2.isEmpty()
	 * @return true si this est incluse dans image2 au sens des pixels allumés false
	 *         sinon
	 */
	@Override
	public boolean isIncludedIn(AbstractImage image2) {
		Iterator<Node> it = this.iterator();
		Iterator<Node> it2 = image2.iterator();
		return isIncludedInAux(it,it2);
	}
	private boolean isIncludedInAux(Iterator<Node> it, Iterator<Node> it2) {
		if (it.isEmpty() && it2.isEmpty()) {
			return true;
		} else if (it.isEmpty() || it2.isEmpty()) {
			return false;
		} else {
			if (it.getValue().state == 1) {
				return it2.getValue().state == 1;
			} else if (it2.getValue().state == 1) {
				return true;
			} else if (it.getValue().state != 0) {
				it.goLeft();
				it2.goLeft();
				boolean coteD = isIncludedInAux(it, it2);
				it.goUp();
				it2.goUp();
				it.goRight();
				it2.goRight();
				boolean coteG = isIncludedInAux(it, it2);
				it.goUp();
				it2.goUp();
				return coteG && coteD;
			} else {
				return true;
			}
		}
	}

}