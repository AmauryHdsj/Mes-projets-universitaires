package HerbautDeSaintJust1.Raulais2.crossword;



import HerbautDeSaintJust1.Raulais2.crossword.Controller.MenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class CrosswordGame extends Application {
    // Instance unique de Stage
    private static Stage instance;

    // Méthode pour obtenir l'instance de Stage
    public static Stage getInstance() {
        return instance;
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        // Charger le fichier FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("./View1/Menu.fxml"));
        // Charger la racine de l'interface utilisateur depuis le fichier FXML
        Parent root = loader.load();
        // Obtenir le contrôleur associé à l'interface utilisateur chargée
        MenuController controller = loader.getController();

        // Initialiser le contrôleur
        controller.initialize();

        // Configurer la fenêtre principale
        primaryStage.setTitle("Mot croisé"); // Titre de la fenêtre
        primaryStage.setScene(new Scene(root, 600, 600)); // Définir la scène avec une taille de 600x600 pixels
        primaryStage.show(); // Afficher la fenêtre principale
        primaryStage.setResizable(false);
    }

    // Méthode principale qui lance l'application
    public static void main(String[] args) {
        launch(args); // Démarrer l'application JavaFX
    }
}
