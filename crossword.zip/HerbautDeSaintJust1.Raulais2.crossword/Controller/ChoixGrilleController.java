package HerbautDeSaintJust1.Raulais2.crossword.Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.SQLException;

public class ChoixGrilleController {


    private Stage primaryStage; // Référence à la fenêtre principale

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }


    @FXML
    private void lancerPartie(String buttonId) throws RuntimeException {
        try {
            // Charger la vue de la grille avec son contrôleur associé
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View1/IHM.fxml"));
            Parent grilleView = loader.load();

            // Obtenir le contrôleur de la grille pour initialiser la grille si nécessaire
            CrosswordController grilleController = loader.getController();
            grilleController.initializeGame(Integer.parseInt(buttonId)); // Passer l'ID du bouton

            // Charger la nouvelle scène dans la fenêtre principale
            Scene scene = new Scene(grilleView);

            primaryStage.setScene(scene);
            grilleController.setPrimaryStage(primaryStage);
            primaryStage.show();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleButtonClick(ActionEvent event) {
        String buttonId = ((Button) event.getSource()).getId(); // Récupérer l'ID du bouton
        lancerPartie(buttonId); // Appeler lancerPartie() avec l'ID du bouton
    }

    @FXML
    public void quitter() {
        try {
            // Charger le fichier FXML de Menu avec son contrôleur associé
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View1/Menu.fxml"));
            Parent menuView = loader.load();

            // Obtenir le contrôleur de Menu pour initialiser si nécessaire
            MenuController menuController = loader.getController();
            menuController.initialize(); // Initialiser le menu si nécessaire

            // Charger la nouvelle scène dans la fenêtre principale
            Scene scene = new Scene(menuView);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
