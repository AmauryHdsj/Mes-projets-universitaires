package HerbautDeSaintJust1.Raulais2.crossword.Controller;

import HerbautDeSaintJust1.Raulais2.crossword.Controller.CrosswordController;
import HerbautDeSaintJust1.Raulais2.crossword.Controller.ChoixGrilleController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

public class MenuController {
    @FXML
    private Button grille_button;
    @FXML
    private Button exit;



    public void initialize() {
    }

    @FXML
    private void choixDesGrilles(){
        try {
            // Charger la vue de la grille avec son contrôleur associé
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View1/Grille.fxml"));
            Parent grilleView = loader.load();

            // Obtenir le contrôleur de la grille pour initialiser la grille si nécessaire
            ChoixGrilleController grilleController = loader.getController();

            // Créer une nouvelle scène avec la vue de la grille
            Scene scene = new Scene(grilleView);

            // Obtenir la fenêtre principale et définir la nouvelle scène
            Stage stage = (Stage) grille_button.getScene().getWindow();
            grilleController.setPrimaryStage(stage);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void jouerGrille() {
        try {
            // Charger la vue de la grille avec son contrôleur associé
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View1/IHM.fxml"));
            Parent grilleView = loader.load();

            // Obtenir le contrôleur de la grille pour initialiser la grille si nécessaire
            CrosswordController grilleController = loader.getController();
            grilleController.initializeGame(generateRandomNumber()); // Initialiser la grille si nécessaire

            // Créer une nouvelle scène avec la vue de la grille
            Scene scene = new Scene(grilleView);

            // Obtenir la fenêtre principale et définir la nouvelle scène
            Stage stage = (Stage) grille_button.getScene().getWindow();
            grilleController.setPrimaryStage(stage);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    private void quitterJeux(){
        // Obtenir la fenêtre principale
        Stage stage = (Stage) exit.getScene().getWindow();
        // Fermer la fenêtre
        stage.close();
    }
    public static int generateRandomNumber() {
        // Créer un objet Random
        Random random = new Random();
        // Générer un nombre aléatoire entre 1 et 11 (inclus)
        return random.nextInt(11) + 1;
    }


    public void setPrimaryStage(Stage primaryStage) {
    }
}
