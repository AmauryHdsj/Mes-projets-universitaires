package HerbautDeSaintJust1.Raulais2.crossword.Controller;

import HerbautDeSaintJust1.Raulais2.crossword.Model.Clue;
import HerbautDeSaintJust1.Raulais2.crossword.Model.Crossword;
import HerbautDeSaintJust1.Raulais2.crossword.Model.CrosswordSquare;
import HerbautDeSaintJust1.Raulais2.crossword.Model.DataBase;
import javafx.animation.ScaleTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.SQLException;
import java.util.stream.Collectors;

public class CrosswordController {
    @FXML
    private GridPane gridPane;
    @FXML
    private ListView<ObservableList<Clue>> verticalDefinitionsListView;
    @FXML
    private ListView<ObservableList<Clue>> horizontalDefinitionsListView;
    private Crossword crossword;
    private final DataBase dataBase;
    private Label caseCourantLabel;
    private boolean isHorizontalDirection = true;
    private Stage primaryStage;
    private static final String SQUARE_LABEL_CURRENT = "square-label-current";
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    // Constructeur du contrôleur
    public CrosswordController() {
        // Initialisation de la base de données et du puzzle de mots croisés
        dataBase = new DataBase();

    }

    // Méthode d'initialisation appelée après le chargement de l'interface graphique
    public void initializeGame(int number) throws SQLException {
        // Initialisation des définitions
        crossword = Crossword.createPuzzle(dataBase, number);
        initialize();
        initialiserDef();
    }
    private void initialize(){

        // Parcours de la grille pour afficher les cases
        for (int row = 0; row < crossword.getHeight(); row++) {
            for (int col = 0; col < crossword.getWidth(); col++) {
                Label label = new Label(" ");
                // Ajout des classes CSS pour le style des cases
                if (crossword.isBlackSquare(row, col)) {
                    label.getStyleClass().add("square-label-black");
                } else {
                    configureTextChangeListener(label);
                    label.getStyleClass().add("square-label-white");
                    setLabelEventHandlers(label);
                    label.setFocusTraversable(true);
                }

                gridPane.add(label, col, row);
            }
        }
    }
    // Configuration des gestionnaires d'événements pour une case
    private void setLabelEventHandlers(Label label) {
        label.setOnKeyPressed(this::handleKeyPressed);
        label.setOnMouseClicked(event -> handleMouseClicked(label));
    }

    // Gestion de l'événement de clic sur une case
    private void handleMouseClicked(Label label) {
        label.getStyleClass().add(SQUARE_LABEL_CURRENT);
        if (caseCourantLabel != null) {
            caseCourantLabel.getStyleClass().remove(SQUARE_LABEL_CURRENT);
        }

        caseCourantLabel = label;
        int row = GridPane.getRowIndex(label);
        int col = GridPane.getColumnIndex(label);

        // Récupérer les indices horizontal et vertical associés à cette position
        String horizontalClue = crossword.getCell(row, col).getHorizontal();
        String verticalClue = crossword.getCell(row, col).getVertical();
        highlightClue(horizontalClue, verticalClue);
    }
    // Méthode pour mettre en surbrillance les définitions horizontales et verticales associées à une case
    private void highlightClue(String clueText, String clueTextBis) {
        if(isHorizontalDirection){
            updateListViewStyle(verticalDefinitionsListView, clueTextBis, "-fx-background-color: #5cb7b5;");
            updateListViewStyle(horizontalDefinitionsListView, clueText, "-fx-background-color: #c42727;");
        }else{
            updateListViewStyle(verticalDefinitionsListView, clueTextBis, "-fx-background-color: #c42727;");
            updateListViewStyle(horizontalDefinitionsListView, clueText, "-fx-background-color: #5cb7b5;");
        }

    }
    // Recherche de l'index de la définition dans une liste
    private int findClueIndex(ListView<ObservableList<Clue>> listView, String clueText) {
        ObservableList<ObservableList<Clue>> items = listView.getItems();
        for (int i = 0; i < items.size(); i++) {
            ObservableList<Clue> item = items.get(i);
            for (Clue clue : item) {
                if (clue.getClue().equals(clueText)) {
                    return i;
                }
            }
        }
        return -1; // Clue non trouvé
    }
    // Méthode pour mettre à jour le style visuel des cellules dans une ListView en fonction de l'indice de la définition spécifiée
    private void updateListViewStyle(ListView<ObservableList<Clue>> listView, String clueText, String style) {
        // Recherche de l'indice de la définition dans la liste
        int index = findClueIndex(listView, clueText);

        // Définition d'une nouvelle usine de cellules pour la ListView
        listView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(ObservableList<Clue> item, boolean empty) {
                super.updateItem(item, empty);
                if (index != -1 && getIndex() == index) {
                    setStyle(style);
                } else {
                    setStyle(null);
                }
                if (!empty && item != null && !item.isEmpty()) {
                    setText(item.stream().map(Object::toString).collect(Collectors.joining(" ")));
                    setOnMouseClicked(event -> handleClueClicked(getItem()));
                    caseCourantLabel.requestFocus(); // Rétablir le focus sur la grille
                } else {
                    setText(null);
                }
            }
        });
    }

    private void initialiserDef() {
        // Initialisation des listes verticales et horizontales
        initializeListView(verticalDefinitionsListView);
        initializeListView(horizontalDefinitionsListView);

        // Ajout des définitions verticales à la liste
        for (Clue clue : crossword.getVerticalClues()) {
            verticalDefinitionsListView.getItems().add(FXCollections.observableArrayList(clue));
        }

        // Ajout des définitions horizontales à la liste
        for (Clue clue : crossword.getHorizontalClues()) {
            horizontalDefinitionsListView.getItems().add(FXCollections.observableArrayList(clue));
        }
    }

    // Méthode pour initialiser une ListView pour afficher des listes d'indices de mots croisés
    private void initializeListView(ListView<ObservableList<Clue>> listView) {
        listView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(ObservableList<Clue> item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.isEmpty()) {
                    setText(null);
                } else {
                    setText(item.stream()
                            .map(Object::toString)
                            .collect(Collectors.joining(" ")));
                    setOnMouseClicked(event -> {
                        handleClueClicked(getItem());
                        caseCourantLabel.requestFocus(); // Rétablir le focus sur la grille
                    });
                }
            }
        });
    }


    // Gestion de l'événement de clic sur une définition
    private void handleClueClicked(ObservableList<Clue> clueList) {
        int row = clueList.get(0).getRow();
        int column = clueList.get(0).getColumn();
        isHorizontalDirection=clueList.get(0).isHorizontal();

        Node node = gridPane.getChildren().get(row * crossword.getWidth() + column);
        if (node instanceof Label) {
            if (caseCourantLabel != null) {
                caseCourantLabel.getStyleClass().remove(SQUARE_LABEL_CURRENT);
            }
            node.getStyleClass().add(SQUARE_LABEL_CURRENT);
            caseCourantLabel = (Label) node;
            caseCourantLabel.requestFocus();
        }
    }
    //chargé de gérer les événements lorsqu'on appuie sur une touche
    private void handleKeyPressed(KeyEvent event) {
        // Vérifie si une case est sélectionnée
        if (caseCourantLabel != null) {
            // Gère les différents codes de touche pressée
            switch (event.getCode()) {
                case DOWN, LEFT, RIGHT, UP:
                    handleDirectionalKey(event.getCode());
                    break;
                case ENTER:
                    checkSolutionAndShowAlertIfWon();
                    break;
                case BACK_SPACE:
                    deleteLetterAndMoveCursorOppositeDirection();
                    if (isHorizontalDirection) {
                        // Si le mot est horizontal, déplacer le curseur vers la gauche
                        moveCursor(0, -1);
                    } else {
                        // Sinon, le mot est vertical, déplacer le curseur vers le haut
                        moveCursor(-1, 0);
                    }
                    break;
                case W:
                    handleControlW(event);
                    break;
                default:
                    handleLetterKey(event.getText());
                    break;
            }
        }
    }

    private void handleDirectionalKey(KeyCode keyCode) {
        int dx = 0;
        int dy = 0;
        switch (keyCode) {
            case UP:
                dy = -1;
                break;
            case DOWN:
                dy = 1;
                break;
            case LEFT:
                dx = -1;
                break;
            case RIGHT:
                dx = 1;
                break;
        }
        moveCursor(dy, dx);
    }

    private void checkSolutionAndShowAlertIfWon() {
        checkSolution();
        if (gagne()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Félicitations !");
            alert.setHeaderText(null);
            alert.setContentText("Vous avez gagné !");
            alert.showAndWait();
        }
    }

    private void handleControlW(KeyEvent event) {
        if (event.isControlDown()) {
            closeWindow();
        }
    }

    private void handleLetterKey(String letter) {
        if (letter.matches("[a-zA-Z]")) { // Vérifie si c'est une lettre
            // Saisir la lettre dans la case courante
            caseCourantLabel.setText(letter.toUpperCase());
            checkAndUpdateBackground();
            // Déplacement dans la direction du mot
            if (isHorizontalDirection) {
                // Si le mot est horizontal, déplacer le curseur à droite
                moveCursor(0, 1);
            } else {
                // Sinon, le mot est vertical, déplacer le curseur vers le bas
                moveCursor(1, 0);
            }
        }
    }



    // Méthode pour configurer le gestionnaire de changement de la propriété text
    private void configureTextChangeListener(Label label) {
        label.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                // Créer une animation d'agrandissement pour la lettre nouvellement tapée
                ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), label);
                scaleTransition.setToX(1.2); // Grossir
                scaleTransition.setToY(1.2); // Grossir
                scaleTransition.setAutoReverse(true);
                scaleTransition.setOnFinished(e -> {
                    // Rétrécir après l'agrandissement
                    ScaleTransition shrinkTransition = new ScaleTransition(Duration.millis(200), label);
                    shrinkTransition.setToX(1.0);
                    shrinkTransition.setToY(1.0);
                    shrinkTransition.play();
                });
                scaleTransition.play();
            }
        });
    }


    private void closeWindow() {
        // Fermer la fenêtre
        Stage stage = (Stage) caseCourantLabel.getScene().getWindow();
        stage.close();
    }


    private void moveCursor(int deltaRow, int deltaCol) {
        if (caseCourantLabel != null) {
            int currentRow = GridPane.getRowIndex(caseCourantLabel);
            int currentCol = GridPane.getColumnIndex(caseCourantLabel);
            int row = currentRow + deltaRow;
            int col = currentCol + deltaCol;
                // Vérifier les limites du GridPane
                if (row >= 0 && row < gridPane.getRowCount() && col >= 0 && col < gridPane.getColumnCount() &&gridPane.getRowCount()!=2) {
                    Node node = gridPane.getChildren().get(row * gridPane.getColumnCount() + col);

                        // Vérifier si la case est noire
                        if (node instanceof Label && !crossword.isBlackSquare(row, col)) {
                            caseCourantLabel.getStyleClass().remove(SQUARE_LABEL_CURRENT);
                            node.getStyleClass().add(SQUARE_LABEL_CURRENT);
                            caseCourantLabel = (Label) node;

                            // Mettre à jour la direction courante
                            isHorizontalDirection = deltaRow == 0;

                            // Mettre à jour les indices horizontal et vertical associés à cette position
                            String horizontalClue = crossword.getCell(row, col).getHorizontal();
                            String verticalClue = crossword.getCell(row, col).getVertical();
                            highlightClue(horizontalClue, verticalClue);
                        }

                }
            }

    }

    // Vérification de la solution
    private void checkSolution() {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Label label) {
                int row = GridPane.getRowIndex(label);
                int col = GridPane.getColumnIndex(label);
                CrosswordSquare square = crossword.getCell(row, col);
                if (square != null && !label.getText().isEmpty() && !square.isBlack()) {
                    char proposedLetter = label.getText().charAt(0);
                    char solution = square.getSolution();
                    if (proposedLetter == solution || Character.toLowerCase(proposedLetter)==solution) {
                        // Colorier le fond de la case en vert
                        label.setStyle("-fx-background-color: #00FF00;");
                    }
                }
            }
        }
        //rafraichit
        gridPane.requestLayout();
    }
    private void checkAndUpdateBackground() {
        if (caseCourantLabel != null) {
            int row = GridPane.getRowIndex(caseCourantLabel);
            int col = GridPane.getColumnIndex(caseCourantLabel);

            if (crossword.correctCoords(row, col)) {
                CrosswordSquare square = crossword.getCell(row, col);
                if (square != null && !caseCourantLabel.getText().isEmpty() && !square.isBlack()) {
                    char proposedLetter = caseCourantLabel.getText().charAt(0);
                    char solution = square.getSolution();
                    if (proposedLetter != solution && Character.toLowerCase(proposedLetter) != solution) {
                        resetCellStyle(caseCourantLabel);
                    }
                }
            }
        }
    }

    private void deleteLetterAndMoveCursorOppositeDirection() {
        if (caseCourantLabel != null) {
            int row = GridPane.getRowIndex(caseCourantLabel);
            int col = GridPane.getColumnIndex(caseCourantLabel);

            resetCellLabel(caseCourantLabel, row, col);

            gridPane.requestLayout();
        }
    }

    // Réinitialise l'étiquette de la cellule avec une chaîne vide, réinitialise son style et met à jour la case courante
    private void resetCellLabel(Label label, int row, int col) {
        label.setText(""); // Efface le texte de l'étiquette de la cellule
        resetCellStyle(label); // Réinitialise le style de l'étiquette de la cellule
        Node node = gridPane.getChildren().get(row * gridPane.getColumnCount() + col); // Récupère le nœud correspondant à la cellule
        if (node instanceof Label) {
            caseCourantLabel.getStyleClass().remove(SQUARE_LABEL_CURRENT); // Supprime le style
            node.getStyleClass().add(SQUARE_LABEL_CURRENT); // Ajoute la classe CSS à l'étiquette de la cellule actuelle
            caseCourantLabel = (Label) node; // Met à jour la case courante

        }
    }

    // Réinitialise le style de l'étiquette de la cellule
    private void resetCellStyle(Label label) {
        label.setStyle("-fx-background-color: #ffffff;"); // Définit le fond de l'étiquette sur blanc
    }



    // Gestionnaire d'événements pour quitter le jeu
    @FXML
    private void quitterJeux() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../View1/Menu.fxml")); // Charge le fichier FXML du menu
            Parent root = loader.load(); // Charge le parent du fichier FXML
            Scene scene = new Scene(root); // Crée une nouvelle scène avec le parent chargé
            MenuController menuController = loader.getController(); // Récupère le contrôleur du menu
            menuController.setPrimaryStage(primaryStage); // Initialise la scène principale dans le contrôleur du menu
            primaryStage.setScene(scene); // Définit la nouvelle scène sur la scène principale
            primaryStage.show(); // Affiche la scène principale
        } catch (IOException e) {
            e.printStackTrace(); // Affiche les erreurs d'entrée/sortie
        }
    }

    // Gestionnaire d'événements pour réinitialiser la grille du jeu
    @FXML
    public void reset() {
        gridPane.getChildren().clear(); // Efface tous les enfants de la grille
        initialize(); // Réinitialise la grille
    }


    private boolean gagne() {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Label label) {
                int row = GridPane.getRowIndex(label);
                int col = GridPane.getColumnIndex(label);
                CrosswordSquare square = crossword.getCell(row, col);
                if (square != null && !label.getText().isEmpty() && !square.isBlack()) {
                    char proposedLetter = label.getText().charAt(0);
                    char solution = square.getSolution();
                    if (Character.toUpperCase(proposedLetter) != solution && proposedLetter != solution && Character.toLowerCase(proposedLetter)!=solution) {
                        return false; // Si au moins une case correcte est incorrectement remplie, retourne false
                    }
                }
            }
        }
        return true; // Si toutes les cases correctes sont correctement remplies, retourne true
    }

}