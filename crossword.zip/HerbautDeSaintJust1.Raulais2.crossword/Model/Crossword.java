package HerbautDeSaintJust1.Raulais2.crossword.Model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.SQLException;

public class Crossword extends Grid<CrosswordSquare> {


    private ObservableList<Clue> verticalClues;
    private ObservableList<Clue> horizontalClues;

    public Crossword(int height, int width) {
        super(height, width);

        // Initialisation des listes
        verticalClues = FXCollections.observableArrayList();
        horizontalClues = FXCollections.observableArrayList();

        // Initialisation des cellules
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                super.setCell(i, j, new CrosswordSquare());
            }
        }
    }

    public StringProperty propositionProperty(int row, int column) {
        return new SimpleStringProperty(this, String.valueOf(this.getCell(row, column).getProposition()));
    }

    public boolean isBlackSquare(int row, int column) {
        if (!super.correctCoords(row, column)) {
            throw new RuntimeException("Coordonnées non valides");
        }
        return this.getCell(row, column).isBlack();
    }

    public void setBlackSquare(int row, int column, boolean black) {
        if (!this.correctCoords(row, column)) {
            throw new RuntimeException("Coordonnées non valides");
        }else{
            this.getCell(row,column).setBlack(black);
        }
    }

    public char getSolution(int row, int column) {
        if (!this.correctCoords(row, column)) {
            throw new RuntimeException("Coordonnées non valides");
        }
        if(isBlackSquare(row,column)){
            throw new IllegalArgumentException("La case est noire");
        }
        if(this.getCell(row, column).getSolution() != '\0'){
            return this.getCell(row, column).getSolution();
        }
        return '\0';
    }

    public void setSolution(int row, int column, char solution) {
        if(isBlackSquare(row,column)){
            throw new IllegalArgumentException("La case est noire");
        }
        else {
            this.getCell(row, column).setSolution(solution);

        }
    }

    public char getProposition(int row, int column) {
        if (!this.correctCoords(row, column)) {
            throw new RuntimeException("Coordonnées non valides");
        }
        if(isBlackSquare(row,column)){
            throw new IllegalArgumentException("La case est noire");
        }
        if(this.getCell(row, column).getProposition() != '\0'){
        return this.getCell(row, column).getProposition();
        }
        return '\0';
    }

    public void setProposition(int row, int column, char proposition) {
        if (isBlackSquare(row, column)) {
            throw new IllegalArgumentException("La case est noire");
        } else {
            this.getCell(row, column).setProposition(proposition);
        }
    }

    public String getDefinition(int row, int column, boolean horizontal) {
        if(isBlackSquare(row, column)){
        throw new IllegalArgumentException("C'est une case noire");
            }
        if(horizontal){
            return this.getCell(row , column).getHorizontal();
        }else{
            return this.getCell(row,column).getVertical();
        }
    }

    public void setDefinition(int row, int column, boolean horizontal, String definition) {
        if(isBlackSquare(row, column)){
            throw new IllegalArgumentException("C'est une case noire");
        }
        if(horizontal){
            this.getCell(row,column).setHorizontal(definition);
            getHorizontalClues().add(new Clue(definition,row,column,horizontal));
        }else{
            this.getCell(row,column).setVertical(definition);
            getVerticalClues().add(new Clue(definition,row,column,horizontal));
        }
    }

    public ObservableList<Clue> getVerticalClues() {
        return verticalClues;
    }

    public ObservableList<Clue> getHorizontalClues() {
        return horizontalClues;
    }

    public static Crossword createPuzzle(DataBase dataBase, int puzzleNumber) throws SQLException {
        // Récupérer la grille de la base de données en utilisant le numéro de puzzle
        Crossword crossword = dataBase.extractGrid(puzzleNumber);
        return crossword;
    }


    public void printProposition() {
        for (int i = 0; i < getHeight(); i++) {
            for (int j = 0; j < getWidth(); j++) {
                CrosswordSquare cell = this.getCell(i, j);
                System.out.print(cell.getProposition());
            }
            System.out.println();
        }
    }

    public void printSolution() {
        for (int i = 0; i < getHeight(); i++) {
            for (int j = 0; j < getWidth(); j++) {
                CrosswordSquare cell = this.getCell(i, j);
                System.out.print(cell.getSolution());
            }
            System.out.println();
        }
    }
}
