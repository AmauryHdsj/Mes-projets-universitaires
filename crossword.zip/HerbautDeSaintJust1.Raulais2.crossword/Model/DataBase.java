package HerbautDeSaintJust1.Raulais2.crossword.Model;

import java.sql.*;

public class DataBase {
    private Connection connexion;

    public DataBase() {
        try {
            connexion = connecterBD();
        } catch (SQLException e) {
            throw new IllegalArgumentException("Erreur lors de la connexion à la base de données", e);
        }
    }

    public Connection connecterBD() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("Driver JDBC introuvable", e);
        }
        return DriverManager.getConnection("jdbc:------lien base de donnée---------", "admin", "root");
    }

    public Crossword dimension(int numGrille) throws SQLException {
        Crossword grid = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT hauteur, largeur FROM GRID WHERE numero_grille = ?";
            pstmt = connexion.prepareStatement(query);
            pstmt.setInt(1, numGrille);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                int hauteur = rs.getInt("hauteur");
                int largeur = rs.getInt("largeur");
                grid = new Crossword(hauteur, largeur);
                for (int i = 0; i < hauteur; i++) {
                    for (int j = 0; j < largeur; j++) {
                        grid.setBlackSquare(i, j, true);
                    }
                }
            }
        } finally {
            closeResultSet(rs);
            closeStatement(pstmt);
        }
        return grid;
    }

    public Crossword extractGrid(int numGrille) throws SQLException {
        Crossword grid = dimension(numGrille);
        if (grid != null) {
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            try {
                String query = "SELECT * FROM CROSSWORD WHERE numero_grille = ?";
                pstmt = connexion.prepareStatement(query);
                pstmt.setInt(1, numGrille);
                rs = pstmt.executeQuery();

                while (rs.next()) {
                    String solution = rs.getString("solution");
                    String definition = rs.getString("definition");
                    boolean horizontal = rs.getBoolean("horizontal");
                    int ligne = rs.getInt("ligne");
                    int colonne = rs.getInt("colonne");

                    colonne--;
                    ligne--;

                    if (horizontal) {
                        for (int i = 0; i < solution.length(); i++) {
                            grid.setBlackSquare(ligne, colonne + i, false);
                            grid.getCell(ligne, colonne + i).setHorizontal(definition);
                            grid.setSolution(ligne, colonne + i, solution.charAt(i));
                        }
                    } else {
                        for (int i = 0; i < solution.length(); i++) {
                            grid.setBlackSquare(ligne + i, colonne, false);
                            grid.getCell(ligne + i, colonne).setVertical(definition);
                            grid.setSolution(ligne + i, colonne, solution.charAt(i));
                        }
                    }

                    grid.setDefinition(ligne, colonne, horizontal, definition);
                }
            } finally {
                closeResultSet(rs);
                closeStatement(pstmt);
            }
        }
        return grid;
    }

    private void closeResultSet(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void closeStatement(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
