package HerbautDeSaintJust1.Raulais2.crossword.Model;

/**
 * Une grille générique pouvant contenir des éléments de type T.
 */
public class Grid<T> {
    private int height;
    private int width;
    private T[][] gridArray;

    /**
     * Constructeur permettant d'initialiser une grille avec les dimensions spécifiées,
     * avec tous les éléments initialisés à null.
     * @param height Le nombre de lignes de la grille.
     * @param width Le nombre de colonnes de la grille.
     * @throws IllegalArgumentException si height ou width est inférieur à 0.
     */
    public Grid(int height, int width) {
        if (height < 0 || width < 0) {
            throw new IllegalArgumentException("La hauteur et la largeur doivent être positives");
        }
        this.height = height;
        this.width = width;
        this.gridArray = (T[][]) new Object[height][width];
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    /**
     * Vérifie si les coordonnées spécifiées sont valides dans la grille.
     * @param row La rangée.
     * @param column La colonne.
     * @return true si les coordonnées sont valides, sinon false.
     */
    public boolean correctCoords(int row, int column) {
        return (row >= 0 && row < this.height && column >= 0 && column < this.width);
    }

    /**
     * Obtient la valeur de la cellule à la position spécifiée.
     * @param row La rangée de la cellule.
     * @param column La colonne de la cellule.
     * @return La valeur de la cellule.
     * @throws IllegalArgumentException si les coordonnées spécifiées sont incorrectes.
     */
    public T getCell(int row, int column) {
        if (!correctCoords(row, column)) {
            throw new IllegalArgumentException("Coordonnées incorrectes");
        }
        return gridArray[row][column];
    }

    /**
     * Modifie la valeur de la cellule à la position spécifiée.
     * @param row La rangée de la cellule.
     * @param column La colonne de la cellule.
     * @param value La nouvelle valeur de la cellule.
     * @throws IllegalArgumentException si les coordonnées spécifiées sont incorrectes.
     */
    public void setCell(int row, int column, T value) {
        if (!correctCoords(row, column)) {
            throw new IllegalArgumentException("Coordonnées incorrectes");
        }
        gridArray[row][column] = value;
    }

    /**
     * Produit une représentation textuelle de la grille.
     * @return La représentation textuelle de la grille.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < getHeight(); i++) {
            for (int j = 0; j < getWidth(); j++) {
                sb.append(getCell(i, j)).append(" | ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
