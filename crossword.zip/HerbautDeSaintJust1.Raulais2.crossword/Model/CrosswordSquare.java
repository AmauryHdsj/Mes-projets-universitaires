package HerbautDeSaintJust1.Raulais2.crossword.Model;


import javafx.scene.control.Label;

public class CrosswordSquare extends Label {
    private char solution;
    private char proposition;
    private String horizontal;
    private String vertical;
    private boolean isBlack;


    /**
     * Constructeur créant une instance de Crossword doté de 4 instances de Grid, suivant les
     * spécifications données ci-dessous
     */
    public CrosswordSquare() {
        this.isBlack=false;
        this.solution = ' ';
        this.proposition =' ' ;
        this.horizontal = null;
        this.vertical =null;
    }


    public char getProposition() {
        return proposition;
    }

    public char getSolution() {
        return solution;
    }

    public String getHorizontal() {
        return horizontal;
    }

    public String getVertical() {
        return vertical;
    }

    public boolean isBlack() { return isBlack; }

    public void setBlack(boolean black) {
        isBlack = black;
    }

    public void setSolution(char solution) {
        this.solution = solution;
    }

    public void setProposition(char proposition) {
        this.proposition = proposition;
    }

    public void setHorizontal(String horizontal) {
        this.horizontal = horizontal;
    }

    public void setVertical(String vertical) {
        this.vertical = vertical;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Solution: ").append(solution);
        sb.append("Proposition: ").append(proposition);
        sb.append("Horizontal: ").append(horizontal);
        sb.append("Vertical: ").append(vertical);
        sb.append("Noire: ").append(isBlack);
        return sb.toString();
    }

    public char propositionProperty() {
        return proposition;

    }
}