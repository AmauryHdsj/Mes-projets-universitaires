# -*- coding=utf-8 -*-


from pathlib import Path  # built-in useful Path class

from pulp import (
    PULP_CBC_CMD,
    LpMinimize,
    LpProblem,
    LpStatus,
    LpVariable,
    lpSum,
)


# contrainte pour le directeur financier
def set_model_DirecteurFinancier(cabines, prixStock, prixC):
    prob = LpProblem(name='Optimisation de la gestion et du stockage', sense=LpMinimize)
    n = len(cabines)
    # Les variables
    stock = [LpVariable(f'Stock_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    # Variable binaire pour la commande
    commande = [LpVariable(f'commande_{i}', cat='Binary') for i in range(len(cabines))]
    appro = [LpVariable(f'APPRO_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    demandes = cabines
    # The objective function
    prob += lpSum(stock[i] * prixStock + prixC * commande[i] for i in range(len(cabines)))

    # le directeur financier ne veut pas de stock donc commande chaque mois
    for i in range(0, len(cabines)):
        # pas de stock donc approvisionnement du mois doit etre egale a la demande du mois
        prob += appro[i] - demandes[i] == 0
        # commande tout les mois
        prob += commande[i] == 1

    return prob, appro, demandes, stock, commande


# contrainte pour le directeur achat
def set_model_DirecteurAchat(cabines, prixStock, prixC):
    prob = LpProblem(name='Optimisation de la gestion et du stockage', sense=LpMinimize)
    n = len(cabines)
    # Les variables
    stock = [LpVariable(f'Stock_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    commande = [LpVariable(f'commande_{i}', cat='Binary') for i in
                range(len(cabines))]  # Variable binaire pour la commande
    appro = [LpVariable(f'APPRO_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    demandes = cabines
    # The objective function
    prob += lpSum(stock[i] * prixStock + prixC * commande[i] for i in range(len(cabines))), 'Total des couts'
    # approvisionnement de toutes les demandes de la periode pour le premier mois
    prob += appro[0] == sum(demandes)
    prob += commande[0] == 1

    for i in range(len(cabines)):
        # le stock du mois doit etre le total des demandes moins la demande du mois i
        prob += appro[i] + stock[i - 1] - stock[i] - demandes[i] == 0

    return prob, appro, demandes, stock, commande


def set_model_cabine(cabines, prixStock, prixC):
    """Initialisation des variables"""
    prob = LpProblem(name='Optimisation de la gestion et du stockage', sense=LpMinimize)
    n = len(cabines)
    # Les variables
    stock = [LpVariable(f'Stock_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    commande = [LpVariable(f'commande_{i}', cat='Binary') for i in
                range(len(cabines))]  # Variable binaire pour la commande
    appro = [LpVariable(f'APPRO_{i}', lowBound=0, cat='Integer') for i in range(len(cabines))]
    demandes = cabines
    # The objective function
    prob += lpSum(stock[i] * prixStock + prixC * commande[i] for i in range(len(cabines))), 'Total des couts'
    # contrainte de bigM car "Chaque approvisionnement engendre des frais fixes d’un montant de 2000 euros, quelle que
    # soit la quantité  commandée."
    BigM = sum(demandes)

    # Contrainte supplémentaire pour chaque mois
    for i in range(len(cabines)):

        prob += appro[i] >= commande[i]
        prob += appro[i] <= commande[i] * BigM
        if i == 0:
            # contrainte pour le premier mois
            prob += appro[i] - stock[i] - demandes[i] == 0
        elif 0 < i < len(cabines) - 1:
            # contrainte pour les i mois
            prob += appro[i] + stock[i - 1] - stock[i] - demandes[i] == 0
        else:
            # contrainte pour le dernier mois
            prob += appro[i] + stock[i - 1] - demandes[i] == 0

    return prob, appro, demandes, stock, commande


def solve_simple_example():
    # nombre de cabines commandée par mois
    cabines = [100, 200, 500, 700, 1000, 200, 300]
    # prix de la commande
    prixFcommande = 1000
    # prix du stockage de chaque cabine
    prixStockage = 4

    prob, appro, demandes, stock, commande = set_model_cabine(cabines, prixStockage, prixFcommande)

    prob.solve(
        PULP_CBC_CMD(
            msg=False, logPath=Path('./CBC_simple_ex.log'),
        ),
    )

    print_log_output(prob, appro, demandes, stock, commande, cabines, prixFcommande, prixStockage,
                     role="Solution Optimale")

    prob, appro, demandes, stock, commande = set_model_DirecteurFinancier(cabines, prixStockage, prixFcommande)
    prob.solve(
        PULP_CBC_CMD(
            msg=False, logPath=Path('./CBC_simple_ex.log'),
        ),
    )
    print_log_output(prob, appro, demandes, stock, commande, cabines, prixFcommande, prixStockage,
                     role="Solution Directeur Financier")

    prob, appro, demandes, stock, commande = set_model_DirecteurAchat(cabines, prixStockage, prixFcommande)

    prob.solve(
        PULP_CBC_CMD(
            msg=False, logPath=Path('./CBC_simple_ex.log'),
        ),
    )
    print_log_output(prob, appro, demandes, stock, commande, cabines, prixFcommande, prixStockage,
                     role="Solution Directeur Achat")


def print_log_output(prob: LpProblem, appro, demandes, stock, commande, varCabines, varPrixF, varPrixS, role):
    print('-' * 60)
    print(role.center(60, ' '))
    print('-' * 60)
    print()
    print('-' * 50)
    print('Stats')
    print('-' * 50)
    print(f'Number variables: {prob.numVariables()}')
    print(f'Number constraints: {prob.numConstraints()}')
    print()
    print('Time:')
    print(f'- (real) {prob.solutionTime}')
    print(f'- (CPU) {prob.solutionCpuTime}')
    print()

    print(f'Solve status: {LpStatus[prob.status]}')
    print(f'Objective value: {prob.objective.value()}')

    print()
    print('-' * 50)
    print("Variables values")
    print('-' * 50)
    print("Demandes :", varCabines)
    print("Cout d'approvisionnement :", varPrixF)
    print("Cout de stock :", varPrixS)
    print()
    print('-' * 50)
    print("Solutions")
    print('-' * 50)
    print(role, ":", prob.objective.value())
    print()
    print('-' * 60)
    print('| {:<5} | {:<10} | {:<10} | {:<10} | {:<8} |'.format('MOIS', 'APPRO', 'COMMANDE', 'STOCK', 'DEMANDES'))
    print('-' * 60)
    # affichage
    for i in range(len(demandes)):
        appro_value = appro[i].varValue if appro[i].varValue is not None else 'N/A'
        commande_value = commande[i].varValue if commande[i].varValue is not None else 'N/A'
        stock_value = stock[i].varValue if stock[i].varValue is not None else 'N/A'
        print(f'| {i + 1:<5} | {appro_value:<10} | {commande_value:<10} | {stock_value:<10} | {demandes[i]:<8} |')
    print('-' * 60)
    print()
    print()
    print()


if __name__ == '__main__':
    solve_simple_example()
